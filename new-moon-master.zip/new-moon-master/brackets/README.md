![Logo](new-moon-logo.svg)

# New Moon for [Brackets](https://brackets.io)

The optimized dark theme for web development.

![Screenshot](screenshot.png)

## Installation

- Look for "New Moon" in the extensions registry

## Author

- [Tania Rascia](https://www.taniarascia.com)

## License

This project is open source and available under the [MIT License](LICENSE).
