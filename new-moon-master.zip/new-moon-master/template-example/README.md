![Logo](new-moon-logo.svg)

# New Moon for [Example App](https://example.com)

The optimized dark theme for web development.

![Screenshot](screenshot.png)

## Installation

- Instructions to install

## Author

- [Author name](https://www.example.com)

## License

This project is open source and available under the [MIT License](LICENSE).
